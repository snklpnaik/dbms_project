<!doctype html>
<!-- Designed & Developed by Tech Vegan https://bit.ly/2MFT35Q 
		NOT FOR SELLING PURPOSE

        CAN USE FOR COLLEGE/SCHOOL PROJECT SUBMISSION
       
        For More Subscribe YouTube Channel "Tech Vegan" https://bit.ly/2MFT35Q
        
        DESIGNED WITH LOVE FOR ALL
-->
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<script>

    function Sankalp(a) {
		var x = a.n1.value;
		var y = a.n2.value;
		var per = (x/y)*100;
		var perr = parseFloat(per).toFixed( 2 );
		a.n3.value = perr;	
	}
	</script>
</head>

<body>
<form method="post" action="">
<input type="text" name="n1" id="n1" size="5"> / <input type="text" name="n2" id="n2" size="5"> = <input type="text" name="n3" id="n3" size="5" onFocus="Sankalp(this.form)">

</form>
</body>
<!-- Designed & Developed by Tech Vegan https://bit.ly/2MFT35Q 
		NOT FOR SELLING PURPOSE

        CAN USE FOR COLLEGE/SCHOOL PROJECT SUBMISSION
       
        For More Subscribe YouTube Channel "Tech Vegan" https://bit.ly/2MFT35Q
        
        DESIGNED WITH LOVE FOR ALL
--> </html>
