<?php
error_reporting(0);
session_start();
$al = mysqli_connect("localhost","root","","student_info");
date_default_timezone_set("Asia/Mumbai");
?>