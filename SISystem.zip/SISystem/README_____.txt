Please download WAMP(Windows)/XAMPP(Windows)/LAMP(Linux) if you want to host this project locally

WAMP Server 2.4 32bit https://bit.ly/2MNNF0O
WAMP Server 2.5 32bit https://bit.ly/2WJXB0E
WAMP Server 2.5 64bit https://bit.ly/3ehjlqp

========= Text Editors =========
Sublime 32bit 64bit ----------- https://bit.ly/2CJzRD2
Notepad++ 32bit 64bit --------- https://bit.ly/2CK3Gn0
Brackets ---------------------- https://bit.ly/39oPSdz
Visual Studio Code 32bit https://bit.ly/2ONalPK
Visual Studio Code 64bit https://bit.ly/2WJE0hf

Please Subscribe YouTube Channel
"Tech Vegan"

Channel Link: https://bit.ly/2MFT35Q

For MoreProjects (Web & Hardware based)
Visit above Link

Default Admin Username & Password
Username: techvegan
Password: techvegan