<div id="footer">
For sAs | Designed &amp; Programmed By <a href="https://www.ashishvegan.com" class="footerL">sakshiAsankalp</a> | <?php if(!isset($_SESSION['lid'])) { ?> <a href="Admin" class="footerL">Admin Login</a> <?php } else { ?><a href="Admin/home.php" class="footerL">Home</a> | <a href="Admin/logout.php" class="footerL">Logout</a><?php } ?>
</div>