<?php
include_once("connection.php");
$sql_query = "SELECT first_name,middle_name,last_name FROM students WHERE branch = '".$_POST['branch']."' ORDER BY roll_no ASC";
$resultset = mysqli_query($conn, $sql_query) or die("database error:". mysqli_error($conn));
$students = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
	$students[] = $rows;
}