<?php  
      //export.php  
 if(isset($_POST["export"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "student_info");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('First Name','Middle Name','Last Name','Date of Birth'));  
      $query = "SELECT first_name,middle_name,last_name,date_of_birth FROM students WHERE branch = '".$_POST['branch']."';  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  
 ?>



 <?php  
                     while($row = mysqli_fetch_array($result))  
                     {  
                     ?>  
                        <tr>
                    <td><?php echo $row ['first_name']?></td>
                    <td><?php echo $row ['middle_name']?></td>
                    <td><?php echo $row ['last_name']?></td>
                    <td><?php echo $row ['date_of_birth']?></td>
                        </tr> 
                        
                        
                     <?php       
                     }  
                     ?>