<?php 
$conn = mysqli_connect("localhost", "root", "", "student_info");
$query = "LOAD DATA INFILE 'input.csv' INTO TABLE tbl_student_master IGNORE 1 LINES";
if (!mysqli_query($conn, $query)) {
    printf("Errormessage: %s\n", mysqli_error($conn));
}
?